/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// Timer Driver Header
#include <ti/drivers/Timer.h>

//Setup for message states
enum LED_MESSAGES {SOS_MESSAGE, OK_MESSAGE} CURR_MESSAGE, BUTTON_STATE;

//Setup for LED states
enum LED_STATES {LED_RED, LED_GREEN, LED_OFF} LED_STATE;

//SOS Message, 1 call for dots, 3 calls for dashes.
enum LED_STATES sos_Message[] = {
     //S
     LED_RED, LED_OFF,
     LED_RED, LED_OFF,
     LED_RED, LED_OFF, LED_OFF, LED_OFF,

     //O
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF, LED_OFF, LED_OFF,

     //S
     LED_RED, LED_OFF,
     LED_RED, LED_OFF,
     LED_RED,

     //Break between words
     LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF
};

enum LED_STATES ok_Message[] = {

     //O
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF, LED_OFF, LED_OFF,

     //K
     LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,
     LED_RED, LED_OFF,
     LED_GREEN, LED_GREEN, LED_GREEN,

     //Break between words
     LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF
};

void setLEDS() {
    switch(LED_STATE) {

        case LED_RED:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;

        case LED_GREEN:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            break;

        case LED_OFF:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;

        default:
            break;

    }
}

//TimerCallBack Code

//Message counter for ensuring full message is read before transfer

unsigned int message_Counter = 0;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{

    switch(CURR_MESSAGE) {
        case SOS_MESSAGE:

            LED_STATE = sos_Message[message_Counter];

            setLEDS();

            message_Counter++;

            if (message_Counter == (sizeof(sos_Message)/sizeof(sos_Message[0]))) {

                CURR_MESSAGE = BUTTON_STATE;

                message_Counter = 0;
            }
            break;

        case OK_MESSAGE:

            LED_STATE = ok_Message[message_Counter];

            setLEDS();

            message_Counter++;

            if (message_Counter == (sizeof(ok_Message)/sizeof(ok_Message[0]))) {

                CURR_MESSAGE = BUTTON_STATE;

                message_Counter = 0;
            }
            break;

        default:
            break;
    }


}

//Timer initialization values
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;





    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== gpioButtonSwapCallback ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0 or CONFIG_GPIO_BUTTON_1.
 *
 *  Allows for when a button is pressed to switch between the two message states: SOS or OK
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonSwapCallback(uint_least8_t index)
{
    switch(BUTTON_STATE) {

        case SOS_MESSAGE:
            BUTTON_STATE = OK_MESSAGE;
            break;

        case OK_MESSAGE:
            BUTTON_STATE = SOS_MESSAGE;
            break;
        default:
            break;
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    //Setting initial states for LED's to OFF
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    //Setting initial states to SOS_MESSAGE
    BUTTON_STATE = SOS_MESSAGE;
    CURR_MESSAGE = BUTTON_STATE;

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonSwapCallback);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonSwapCallback);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    return (NULL);
}


